Write-Host "This will run a TMForum API CTK"
Write-Host "In order to be able to run it, you need to have"
Write-Host "NodeJS and NPM installed."
Write-Host "Installing npm dependencies..."
Write-Host

cd .\ctk
npm install
npm start
